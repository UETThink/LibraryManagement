/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Admin
 */
public class Book {
    
    private String isbn;
    private String name;
    private String author_id;
    private String genre_id;
    private Integer quantity;
    private String publisher;
    private double price;
    private String date_receive;
    private String description;
    private byte[] Cover;
    private int issued;
    
          
    public Book(){}
    
    public Book(String _isbn, String _name,String _author_id,String _genre_id,Integer _quantity,String _publisher,double _price, String _date_receive,String _description,byte[] _Cover){
            
        this.isbn = _isbn;
        this.name = _name;
        this.author_id = _author_id;
        this.genre_id = _genre_id;
        this.quantity = _quantity;
        this.publisher = _publisher;
        this.price = _price;
        this.date_receive = _date_receive;
        this.description = _description;
        this.Cover = _Cover;
    }   
    
      public int getIssued() {
        return issued;
    }
    
    public void setIssued(int issued) {
        this.issued = issued;
    }
    
    // Phương thức để lấy số lượng sách có sẵn
    public int getAvailable() {
        return quantity - issued;
    }
    
    // Phương thức kiểm tra có thể cho mượn không
    public boolean isAvailableForBorrowing() {
        return getAvailable() > 0;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor_id() {
        return author_id;
    }

    public void setAuthor_id(String author_id) {
        this.author_id = author_id;
    }

    public String getGenre_id() {
        return genre_id;
    }

    public void setGenre_id(String genre_id) {
        this.genre_id = genre_id;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDate_receive() {
        return date_receive;
    }

    public void setDate_receive(String date_receive) {
        this.date_receive = date_receive;
    }

    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }

    public byte[] getCover() {
        return Cover;
    }

    public void setCover(byte[] Cover) {
        this.Cover = Cover;
    }
 
      public void addbook(String _isbn, String _name,String _author_id,String _genre_id,Integer _quantity,String _publisher,double _price, String _date_receive,String _description,byte[] _Cover) {
    String insertQuery = "INSERT INTO `book`(`isbn`, `tentacpham`, `tentacgia`, `theloai`,`soluong`, `nhaxuatban`, `gia`, `ngaynhan`, `mota`, `anhbia`)  VALUES (?,?,?,?,?,?,?,?,?,?)";
   
    try {
        PreparedStatement ps = DB.getConnection().prepareStatement(insertQuery);
                
        ps.setString(1, _isbn);
        ps.setString(2, _name);
        ps.setString(3, _author_id);
        ps.setString(4, _genre_id);
        ps.setInt(5, _quantity);
        ps.setString(6, _publisher);
        ps.setDouble(7, _price);
        ps.setString(8, _date_receive);
         ps.setString(9, _description); 
        ps.setBytes(10, _Cover);
        
        
                if (ps.executeUpdate() != 0) {
            
            JOptionPane.showMessageDialog(null, "Book Added", "Add Book", JOptionPane.INFORMATION_MESSAGE);
        } 
        else {
            JOptionPane.showMessageDialog(null, "Book Not Added", "Add Book", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException ex) {
         Logger.getLogger(Book.class.getName()).log(Level.SEVERE, null, ex);
    }
    
    
}
      
public Book getBookbyName(String name) {
    String query = "SELECT * FROM `book` WHERE LOWER(`tentacpham`) = LOWER(?)";
    try (PreparedStatement ps = DB.getConnection().prepareStatement(query)) {
        ps.setString(1, name); // Ensure this is trimmed
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            return new Book(
                rs.getString("isbn"),
                rs.getString("tentacpham"),
                rs.getString("tentacgia"),
                rs.getString("theloai"),
                rs.getInt("soluong"),
                rs.getString("nhaxuatban"),
                rs.getDouble("gia"),
                rs.getString("ngaynhan"),
                rs.getString("mota"),
                rs.getBytes("anhbia")
            );
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Lỗi truy vấn: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
    }
    return null; // No book found
}

public void updateBook(String _isbn, String _name, String _author_id, String _genre_id, Integer _quantity, String _publisher, double _price, String _date_receive, String _description, byte[] _Cover, boolean imageChanged) throws SQLException {
    String updateQuery;
    if (imageChanged) {
        // If the image is changed, update all fields including the image
        updateQuery = "UPDATE `book` SET `tentacpham`=?, `tentacgia`=?, `theloai`=?, `soluong`=?, `nhaxuatban`=?, `gia`=?, `ngaynhan`=?, `mota`=?, `anhbia`=? WHERE `isbn`=?";
    } else {
        // If the image is not changed, update all fields except the image
        updateQuery = "UPDATE `book` SET `tentacpham`=?, `tentacgia`=?, `theloai`=?, `soluong`=?, `nhaxuatban`=?, `gia`=?, `ngaynhan`=?, `mota`=? WHERE `isbn`=?";
    }

    try (PreparedStatement ps = DB.getConnection().prepareStatement(updateQuery)) {
        int parameterIndex = 1;
        ps.setString(parameterIndex++, _name);
        ps.setString(parameterIndex++, _author_id);
        ps.setString(parameterIndex++, _genre_id);
        ps.setInt(parameterIndex++, _quantity);
        ps.setString(parameterIndex++, _publisher);
        ps.setDouble(parameterIndex++, _price);
        ps.setString(parameterIndex++, _date_receive);
        ps.setString(parameterIndex++, _description);

        if (imageChanged) {
            ps.setBytes(parameterIndex++, _Cover);
            ps.setString(parameterIndex, _isbn); // Set ISBN as the last parameter
        } else {
            ps.setString(parameterIndex, _isbn); // Set ISBN as the last parameter
        }

        int rowsAffected = ps.executeUpdate();
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(null, "Book updated successfully", "Update Book", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Book not updated", "Update Book", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException ex) {
        Logger.getLogger(Book.class.getName()).log(Level.SEVERE, null, ex);
        throw ex; // Re-throw the exception to be handled by the calling method
    }
}
/**
 * Đếm tổng số sách trong thư viện
 * @return Tổng số sách
 */
public int countBooks() {
    int count = 0;
    String query = "SELECT COUNT(*) AS total FROM `book`";
    
    try (PreparedStatement ps = DB.getConnection().prepareStatement(query);
         ResultSet rs = ps.executeQuery()) {
        
        
        
        if (rs.next()) {
            count = rs.getInt("total");
        }
    } catch (SQLException ex) {
        Logger.getLogger(Book.class.getName()).log(Level.SEVERE, null, ex);
    }
    
    return count;
}

public ArrayList<Book> getRecentBooks(int limit) {
    ArrayList<Book> books = new ArrayList<>();
    String query = "SELECT * FROM `book` ORDER BY `ngaynhan` DESC LIMIT ?";
    
    try (PreparedStatement ps = DB.getConnection().prepareStatement(query)) {
        ps.setInt(1, limit);
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()) {
            Book book = new Book(
                rs.getString("isbn"),
                rs.getString("tentacpham"),
                rs.getString("tentacgia"),
                rs.getString("theloai"),
                rs.getInt("soluong"),
                rs.getString("nhaxuatban"),
                rs.getDouble("gia"),
                rs.getString("ngaynhan"),
                rs.getString("mota"),
                rs.getBytes("anhbia")
            );
            books.add(book);
        }
    } catch (SQLException ex) {
        Logger.getLogger(Book.class.getName()).log(Level.SEVERE, null, ex);
    }
    
    return books;
}

public boolean deleteBookByName(String name) throws SQLException {
    String deleteQuery = "DELETE FROM `book` WHERE LOWER(`tentacpham`) = LOWER(?)";
    
    try (PreparedStatement ps = DB.getConnection().prepareStatement(deleteQuery)) {
        ps.setString(1, name.trim());
        
        int rowsDeleted = ps.executeUpdate();
        return rowsDeleted > 0;
        
    } catch (SQLException ex) {
        Logger.getLogger(Book.class.getName()).log(Level.SEVERE, null, ex);
        // Re-throw the exception to be caught in the UI
        throw ex;
    }
}

    public ArrayList<Book> Booklist(String query){

            ArrayList<Book> blist = new ArrayList<>();
        Classes.Func_class func = new Func_class();

    try {

        if(query.equals("")){

            query = "SELECT * FROM book";

        }

        ResultSet rs = func.getData(query);

        Book book;

        while(rs.next()) {
            book = new Book(rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getInt(5),
                    rs.getString(6),
                    rs.getDouble(7),
                    rs.getString(8),
                    rs.getString(9),
                    rs.getBytes(10));
            blist.add(book);

        }
    }catch (SQLException ex) {
        Logger.getLogger(Book.class.getName()).log(Level.SEVERE, null, ex);
    }

            return blist;
    }


public Book getBookbyISBN(String isbn) {
    Book book = null;
    String query = "SELECT * FROM book WHERE isbn = ?";
    
    try (java.sql.Connection conn = DB.getConnection();
         PreparedStatement ps = conn.prepareStatement(query)) {
        
        ps.setString(1, isbn);
        ResultSet rs = ps.executeQuery();
        
        if (rs.next()) {
            book = new Book();
            book.setIsbn(rs.getString("isbn"));
            book.setName(rs.getString("tentacpham"));
            book.setAuthor_id(rs.getString("tentacgia"));
            book.setGenre_id(rs.getString("theloai"));
            book.setPublisher(rs.getString("nhaxuatban"));
            book.setQuantity(rs.getInt("soluong"));
            book.setPrice(rs.getDouble("gia"));
            book.setDate_receive(rs.getString("ngaynhan"));
            book.setCover(rs.getBytes("anhbia"));
            
            // Lấy giá trị từ cột issued
            book.setIssued(rs.getInt("issued"));
        }
    } catch (SQLException ex) {
        Logger.getLogger(Book.class.getName()).log(Level.SEVERE, null, ex);
    }
    
    return book;
}

public boolean isBookAvailable(String isbn) {
    String query = "SELECT `soluong`, (SELECT COUNT(*) FROM `borrow` WHERE `book_isbn` = ? AND `status` = `issued`) as borrowed FROM `book` WHERE `isbn` = ?";
    
    try (PreparedStatement ps = DB.getConnection().prepareStatement(query)) {
        ps.setString(1, isbn);
        ps.setString(2, isbn);
        
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            int totalQuantity = rs.getInt("soluong");
            int borrowedQuantity = rs.getInt("borrowed");
            
            return totalQuantity > borrowedQuantity;
        }
    } catch (SQLException ex) {
        Logger.getLogger(Book.class.getName()).log(Level.SEVERE, null, ex);
    }
    
    return false;
}

public boolean isMemberEligible(int memberId) {
    // Kiểm tra số sách đang mượn
    String query = "SELECT COUNT(*) as borrowed FROM `borrow` WHERE `member_id` = ? AND `returned` = 0";
    
    try (PreparedStatement ps = DB.getConnection().prepareStatement(query)) {
        ps.setInt(1, memberId);
        
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            int borrowedCount = rs.getInt("borrowed");
            
            // Giả sử mỗi thành viên chỉ được mượn tối đa 5 cuốn
            return borrowedCount < 5;
        }
    } catch (SQLException ex) {
        Logger.getLogger(Borrow.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null, "Lỗi truy vấn: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
    }
    
    return false;
}

}
