package Classes;

import Classes.DB;
import com.mysql.cj.xdevapi.Statement;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author Acer
 */
public class Func_class {

    // Xóa dòng này:
    // Classes.Func_class func = new Classes.Func_class();
    // Lấy hình ảnh
    /**
     * Hiển thị hình ảnh vừa khít với khung JLabel, duy trì tỷ lệ khung hình gốc
     */
    public void displayImage(int width, int height, byte[] imageBytes, String imagePath, JLabel label) {
        try {
            // Tải hình ảnh từ bytes hoặc đường dẫn
            BufferedImage originalImage = null;

            if (imageBytes != null && imageBytes.length > 0) {
                try (ByteArrayInputStream bis = new ByteArrayInputStream(imageBytes)) {
                    originalImage = ImageIO.read(bis);
                }
            } else if (imagePath != null && !imagePath.isEmpty()) {
                originalImage = ImageIO.read(new File(imagePath));
            }

            if (originalImage == null) {
                System.err.println("Failed to load image");
                return;
            }

            // Lấy kích thước thực tế của JLabel
            int labelWidth = label.getWidth();
            int labelHeight = label.getHeight();

            // Nếu JLabel chưa được render, sử dụng kích thước được cung cấp
            if (labelWidth <= 0) {
                labelWidth = width;
            }
            if (labelHeight <= 0) {
                labelHeight = height;
            }

            // Tính toán tỷ lệ để duy trì tỷ lệ khung hình
            double widthRatio = (double) labelWidth / originalImage.getWidth();
            double heightRatio = (double) labelHeight / originalImage.getHeight();
            double scaleFactor = Math.min(widthRatio, heightRatio);

            // Tính toán kích thước mới
            int scaledWidth = (int) (originalImage.getWidth() * scaleFactor);
            int scaledHeight = (int) (originalImage.getHeight() * scaleFactor);

            // Tạo ảnh đã được thu nhỏ
            Image scaledImage = originalImage.getScaledInstance(scaledWidth, scaledHeight, Image.SCALE_SMOOTH);

            // Thiết lập ảnh cho JLabel
            label.setIcon(new ImageIcon(scaledImage));
            label.setText(""); // Xóa text nếu có

            // Căn giữa ảnh trong JLabel
            label.setHorizontalAlignment(JLabel.CENTER);
            label.setVerticalAlignment(JLabel.CENTER);

        } catch (IOException ex) {
            System.err.println("Error displaying image: " + ex.getMessage());
        }
    }

    public String selectImage() {

        JFileChooser filechooser = new JFileChooser();
        filechooser.setDialogTitle("Chọn tệp ảnh của bạn");
        filechooser.setCurrentDirectory(new File("C:\\Program Files"));
        FileNameExtensionFilter extensionFilter = new FileNameExtensionFilter("Image", ".png", ".jpg", "jpeg");
        filechooser.addChoosableFileFilter(extensionFilter);

        int fileState = filechooser.showSaveDialog(null);
        String path = "";
        if (fileState == JFileChooser.APPROVE_OPTION) {
            path = filechooser.getSelectedFile().getAbsolutePath();

        }
        return path;
    }

    public void customTableHeader(JTable table, Color backgroundColor, int fontSize) {
        table.getTableHeader().setBackground(backgroundColor);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setFont(new Font("Verdana", Font.BOLD, fontSize));
        table.getTableHeader().setOpaque(false);
    }

    public ResultSet getData(String query) {
        ResultSet resultSet = null;
        try {
            System.out.println("SQL Query: " + query); // In câu truy vấn
            PreparedStatement preparedStatement = DB.getConnection().prepareStatement(query);
            resultSet = preparedStatement.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultSet;
    }
}
