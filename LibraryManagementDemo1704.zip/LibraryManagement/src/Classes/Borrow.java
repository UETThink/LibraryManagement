package Classes;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 * Lớp quản lý hoạt động mượn/trả sách
 */
public class Borrow {
    private int id;
    private String bookIsbn;
    private int memberId;
    private Date borrowDate;
    private Date dueDate;
    private Date returnDate;
    private boolean returned;
    private String note;
    
    // Constructor mặc định
    public Borrow() {}
    
    // Constructor đầy đủ
    public Borrow(int id, String bookIsbn, int memberId, Date borrowDate, 
                  Date dueDate, Date returnDate, boolean returned, String note) {
        this.id = id;
        this.bookIsbn = bookIsbn;
        this.memberId = memberId;
        this.borrowDate = borrowDate;
        this.dueDate = dueDate;
        this.returnDate = returnDate;
        this.returned = returned;
        this.note = note;
    }
    
    // Getters và Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getBookIsbn() { return bookIsbn; }
    public void setBookIsbn(String bookIsbn) { this.bookIsbn = bookIsbn; }
    
    public int getMemberId() { return memberId; }
    public void setMemberId(int memberId) { this.memberId = memberId; }
    
    public Date getBorrowDate() { return borrowDate; }
    public void setBorrowDate(Date borrowDate) { this.borrowDate = borrowDate; }
    
    public Date getDueDate() { return dueDate; }
    public void setDueDate(Date dueDate) { this.dueDate = dueDate; }
    
    public Date getReturnDate() { return returnDate; }
    public void setReturnDate(Date returnDate) { this.returnDate = returnDate; }
    
    public boolean isReturned() { return returned; }
    public void setReturned(boolean returned) { this.returned = returned; }
    
    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }
    
    /**
     * Thêm thông tin mượn sách mới
     * @param bookIsbn ISBN của sách
     * @param memberId ID của thành viên
     * @param borrowDate Ngày mượn
     * @param dueDate Ngày hẹn trả
     * @param note Ghi chú
     * @return true nếu thêm thành công, false nếu thất bại
     */
    public boolean addBorrow(String bookIsbn, int memberId, Date borrowDate, Date dueDate, String note) {
        // Kiểm tra sách có sẵn để mượn không
        if (!isBookAvailable(bookIsbn)) {
            JOptionPane.showMessageDialog(null, "Sách này hiện không có sẵn để mượn!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Kiểm tra thành viên có đủ điều kiện mượn sách không
        if (!isMemberEligible(memberId)) {
            JOptionPane.showMessageDialog(null, "Thành viên không đủ điều kiện mượn sách!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        String query = "INSERT INTO `borrow` (`book_isbn`, `member_id`, `borrow_date`, `duedate`, `returned`, `note`) VALUES (?, ?, ?, ?, 0, ?)";
        
        try (PreparedStatement ps = DB.getConnection().prepareStatement(query)) {
            ps.setString(1, bookIsbn);
            ps.setInt(2, memberId);
            ps.setDate(3, new java.sql.Date(borrowDate.getTime()));
            ps.setDate(4, new java.sql.Date(dueDate.getTime()));
            ps.setString(5, note);
            
            int result = ps.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(null, "Thêm thông tin mượn sách thành công!", "Thành công", JOptionPane.INFORMATION_MESSAGE);
                
                // Thông báo cho các listener
                
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Không thể thêm thông tin mượn sách!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Borrow.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Lỗi SQL: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    /**
     * Cập nhật thông tin trả sách
     * @param id ID của bản ghi mượn sách
     * @param returnDate Ngày trả
     * @param note Ghi chú
     * @return true nếu cập nhật thành công, false nếu thất bại
     */
    public boolean returnBook(int id, Date returnDate, String note) {
        String query = "UPDATE `borrow` SET `returned` = 1, `return_date` = ?, `note` = ? WHERE `id` = ?";
        
        try (PreparedStatement ps = DB.getConnection().prepareStatement(query)) {
            ps.setDate(1, new java.sql.Date(returnDate.getTime()));
            ps.setString(2, note);
            ps.setInt(3, id);
            
            int result = ps.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(null, "Cập nhật thông tin trả sách thành công!", "Thành công", JOptionPane.INFORMATION_MESSAGE);
                
                // Thông báo cho các listener
               
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Không thể cập nhật thông tin trả sách!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Borrow.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Lỗi SQL: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
   
    
    /**
     * Trả sách theo ISBN và ID thành viên
     * @param memberId ID của thành viên
     * @param bookISBN ISBN của sách
     * @return true nếu trả thành công, false nếu thất bại
     */
    public boolean returnBookByMemberAndISBN(int memberId, String bookISBN) {
        String query = "UPDATE `borrow` SET `returned` = 1, `return_date` = CURDATE() WHERE `member_id` = ? AND `book_isbn` = ? AND `returned` = 0";

        try (PreparedStatement ps = DB.getConnection().prepareStatement(query)) {
            ps.setInt(1, memberId);
            ps.setString(2, bookISBN);

            int result = ps.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(null, "Trả sách thành công!", "Thành công", JOptionPane.INFORMATION_MESSAGE);
                
                // Thông báo cho các listener
                
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Không tìm thấy thông tin mượn sách này!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Borrow.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Lỗi SQL: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    /**
     * Kiểm tra sách có sẵn để mượn không
     * @param isbn ISBN của sách
     * @return true nếu sách có sẵn, false nếu không
     */
    public boolean isBookAvailable(String isbn) {
        String query = "SELECT `soluong`, (SELECT COUNT(*) FROM `borrow` WHERE `book_isbn` = ? AND `returned` = 0) as borrowed FROM `book` WHERE `isbn` = ?";
        
        try (PreparedStatement ps = DB.getConnection().prepareStatement(query)) {
            ps.setString(1, isbn);
            ps.setString(2, isbn);
            
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int totalQuantity = rs.getInt("soluong");
                int borrowedQuantity = rs.getInt("borrowed");
                
                return totalQuantity > borrowedQuantity;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Borrow.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
    
    /**
     * Kiểm tra thành viên có đủ điều kiện mượn sách không
     * @param memberId ID của thành viên
     * @return true nếu thành viên đủ điều kiện, false nếu không
     */
    public boolean isMemberEligible(int memberId) {
        // Kiểm tra số sách đang mượn
        String query = "SELECT COUNT(*) as borrowed FROM `borrow` WHERE `member_id` = ? AND `returned` = 0";
        
        try (PreparedStatement ps = DB.getConnection().prepareStatement(query)) {
            ps.setInt(1, memberId);
            
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int borrowedCount = rs.getInt("borrowed");
                
                // Giả sử mỗi thành viên chỉ được mượn tối đa 5 cuốn
                return borrowedCount < 5;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Borrow.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
    
    /**
     * Kiểm tra xem thành viên có đang mượn sách này không
     * @param memberId ID của thành viên
     * @param bookISBN ISBN của sách
     * @return true nếu đang mượn, false nếu không
     */
    public boolean isBookBorrowedByMember(int memberId, String bookISBN) {
        String query = "SELECT COUNT(*) FROM `borrow` WHERE `member_id` = ? AND `book_isbn` = ? AND `returned` = 0";

        try (PreparedStatement ps = DB.getConnection().prepareStatement(query)) {
            ps.setInt(1, memberId);
            ps.setString(2, bookISBN);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Borrow.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }
    
    /**
     * Lấy danh sách các sách đang được mượn
     * @return Danh sách các bản ghi mượn sách
     */
    public List<Borrow> getBorrowedBooks() {
        List<Borrow> borrowList = new ArrayList<>();
        String query = "SELECT * FROM `borrow` WHERE `returned` = 0";
        
        try (PreparedStatement ps = DB.getConnection().prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                Borrow borrow = new Borrow(
                    rs.getInt("id"),
                    rs.getString("book_isbn"),
                    rs.getInt("member_id"),
                    rs.getDate("borrow_date"),
                    rs.getDate("duedate"),
                    rs.getDate("return_date"),
                    rs.getBoolean("returned"),
                    rs.getString("note")
                );
                
                borrowList.add(borrow);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Borrow.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return borrowList;
    }
    
    /**
     * Lấy danh sách các sách đã được mượn bởi một thành viên
     * @param memberId ID của thành viên
     * @return Danh sách các bản ghi mượn sách
     */
    public List<Borrow> getMemberBorrowedBooks(int memberId) {
        List<Borrow> borrowList = new ArrayList<>();
        String query = "SELECT * FROM `borrow` WHERE `member_id` = ? AND `returned` = 0";
        
        try (PreparedStatement ps = DB.getConnection().prepareStatement(query)) {
            ps.setInt(1, memberId);
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Borrow borrow = new Borrow(
                    rs.getInt("id"),
                    rs.getString("book_isbn"),
                    rs.getInt("member_id"),
                    rs.getDate("borrow_date"),
                    rs.getDate("duedate"),
                    rs.getDate("return_date"),
                    rs.getBoolean("returned"),
                    rs.getString("note")
                );
                
                borrowList.add(borrow);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Borrow.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return borrowList;
    }
    
    /**
     * Đếm số sách quá hạn
     * @return Số lượng sách quá hạn
     */
    public int countOverdueBooks() {
        int count = 0;
        String query = "SELECT COUNT(*) AS total FROM `borrow` WHERE `returned` = 0 AND `duedate` < CURDATE()";
        
        try (PreparedStatement ps = DB.getConnection().prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                count = rs.getInt("total");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Borrow.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return count;
    }
    
    /**
     * Lấy danh sách sách quá hạn
     * @return Danh sách các bản ghi mượn sách quá hạn
     */
    public List<Borrow> getOverdueBooks() {
        List<Borrow> borrowList = new ArrayList<>();
        String query = "SELECT * FROM `borrow` WHERE `returned` = 0 AND `duedate` < CURDATE()";
        
        try (PreparedStatement ps = DB.getConnection().prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                Borrow borrow = new Borrow(
                    rs.getInt("id"),
                    rs.getString("book_isbn"),
                    rs.getInt("member_id"),
                    rs.getDate("borrow_date"),
                    rs.getDate("duedate"),
                    rs.getDate("return_date"),
                    rs.getBoolean("returned"),
                    rs.getString("note")
                );
                
                borrowList.add(borrow);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Borrow.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return borrowList;
    }
}