/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import Form.ReturnBook;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Admin
 */
public class Issue_Book {

    private String book_ISBN;
    private int member_id;
    private String Status;
    private String issue_Date;
    private String Return_Date;
    private String _note;

    public Issue_Book(String _book_ISBN, int _member_id, String _Status, String _issue_Date, String _Return_Date, String _note) {
        this.book_ISBN = _book_ISBN;
        this.member_id = _member_id;
        this.Status = _Status;
        this.issue_Date = _issue_Date;
        this.Return_Date = _Return_Date;
        this._note = _note;
    }

    public Issue_Book() {
    }

    public String getBook_ISBN() {
        return book_ISBN;
    }

    public void setBook_ISBN(String book_ISBN) {
        this.book_ISBN = book_ISBN;
    }

    public int getMember_id() {
        return member_id;
    }

    public void setMember_id(int member_id) {
        this.member_id = member_id;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public String getIssue_Date() {
        return issue_Date;
    }

    public void setIssue_Date(String issue_Date) {
        this.issue_Date = issue_Date;
    }

    public String getReturn_Date() {
        return Return_Date;
    }

    public void setReturn_Date(String Return_Date) {
        this.Return_Date = Return_Date;
    }

    public String getNote() {
        return _note;
    }

    public void setNote(String _note) {
        this._note = _note;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    Book book = new Book();

    public int countBorrowedBooks() {
        int count = 0;
        String query = "SELECT COUNT(*) AS total FROM `borrow` WHERE `Status` = 'Cho mượn' OR `Status` = 'Mượn sách'";

        try (java.sql.Connection conn = DB.getConnection(); PreparedStatement ps = conn.prepareStatement(query); ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                count = rs.getInt("total");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Issue_Book.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null,
                    "Lỗi khi đếm số sách đang mượn: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }

        return count;
    }

    public boolean addIssue(String _book_ISBN, int _member_id, String _Status,
            String _issue_Date, String _Return_Date, String _note_) {
        Connection conn = null;
        try {
            // Kiểm tra sách có thể cho mượn không
            if (!checkBookAvailability(_book_ISBN)) {
                JOptionPane.showMessageDialog(null,
                        "Sách này hiện không có sẵn để mượn!",
                        "Không thể mượn", JOptionPane.ERROR_MESSAGE);
                return false;
            }

            // Tạo kết nối và bắt đầu giao dịch
            conn = DB.getConnection();
            conn.setAutoCommit(false);

            // Thêm bản ghi mượn sách
            String insertQuery = "INSERT INTO `borrow`(`book_isbn`, `member_id`, `Status`, `issue_date`, `return_date`, `note`) VALUES (?,?,?,?,?,?)";

            try (PreparedStatement ps = conn.prepareStatement(insertQuery)) {
                ps.setString(1, _book_ISBN);
                ps.setInt(2, _member_id);
                ps.setString(3, _Status);
                ps.setString(4, _issue_Date);
                ps.setString(5, _Return_Date);
                ps.setString(6, _note_);

                int result = ps.executeUpdate();

                if (result > 0) {
                    // Cập nhật số lượng sách đã mượn, đảm bảo giá trị không âm
                    String updateBookQuery = "UPDATE `book` SET `issued` = GREATEST(0, `issued` + 1) WHERE `isbn` = ?";
                    try (PreparedStatement psBook = conn.prepareStatement(updateBookQuery)) {
                        psBook.setString(1, _book_ISBN);
                        int bookResult = psBook.executeUpdate();

                        if (bookResult > 0) {
                            // Hoàn tất giao dịch
                            conn.commit();

                            JOptionPane.showMessageDialog(null,
                                    "Thêm thông tin mượn sách thành công!",
                                    "Mượn sách", JOptionPane.INFORMATION_MESSAGE);
                            return true;
                        }
                    }
                }

                // Nếu có lỗi, rollback giao dịch
                conn.rollback();
                JOptionPane.showMessageDialog(null,
                        "Không thể thêm thông tin mượn sách",
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (SQLException ex) {
            try {
                // Rollback giao dịch nếu có lỗi
                if (conn != null) {
                    conn.rollback();
                }
            } catch (SQLException rollbackEx) {
                Logger.getLogger(Issue_Book.class.getName()).log(Level.SEVERE,
                        "Lỗi khi rollback giao dịch", rollbackEx);
            }

            Logger.getLogger(Issue_Book.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null,
                    "Lỗi: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            try {
                // Đóng kết nối
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException closeEx) {
                Logger.getLogger(Issue_Book.class.getName()).log(Level.SEVERE,
                        "Lỗi khi đóng kết nối", closeEx);
            }
        }
    }

    public int countData(String _book_isbn) {
        int total = 0;
        ResultSet rs;
        PreparedStatement st;

        try {
            st = DB.getConnection().prepareStatement("SELECT COUNT(*) as total FROM `borrow` WHERE `book_isbn` = ? AND `status` = 'issued'");

            st.setString(1, _book_isbn);
            rs = st.executeQuery();

            if (rs.next()) {
                total = rs.getInt("total"); // Sử dụng chỉ số cột thay vì tên cột
            }
        } catch (SQLException ex) {
            Logger.getLogger(Issue_Book.class.getName()).log(Level.SEVERE, null, ex);
        }

        return total;
    }

    public boolean checkBookAvailability(String isbn) {
        try {
            // Lấy thông tin sách từ cơ sở dữ liệu
            Book selectedBook = book.getBookbyISBN(isbn);

            if (selectedBook == null) {
                return false; // Sách không tồn tại
            }

            // Lấy số lượng sách và số lượng đã mượn
            int quantity = selectedBook.getQuantity();
            int issued = selectedBook.getIssued();

            // Tính số lượng sách còn lại có thể cho mượn
            int available = quantity - issued;

            // Nếu có ít nhất 1 quyển còn lại, có thể cho mượn
            return available > 0;
        } catch (Exception ex) {
            Logger.getLogger(Issue_Book.class.getName()).log(Level.SEVERE,
                    "Lỗi khi kiểm tra tình trạng sách: " + ex.getMessage(), ex);
            return false;
        }
    }

    public ArrayList<Issue_Book> IssueBooklist(String status) {
        ArrayList<Issue_Book> issblist = new ArrayList<>();
        Classes.Func_class func = new Func_class();
        String query;

        if (status.equals("Tất cả") || status.isEmpty()) {
            query = "SELECT * FROM `borrow`";
        } else {
            query = "SELECT * FROM `borrow` WHERE `Status` = ?";  // Use a placeholder
        }

        try {
            PreparedStatement ps = DB.getConnection().prepareStatement(query); // Use DB.getConnection()
            if (!status.equals("Tất cả") && !status.isEmpty()) {
                ps.setString(1, status);  // Set the status value
            }

            ResultSet rs = ps.executeQuery();
            Issue_Book issueBook;

            while (rs.next()) {
                issueBook = new Issue_Book(rs.getString(1), rs.getInt(2), rs.getString(3),
                        rs.getString(4), rs.getString(5), rs.getString(6));
                issblist.add(issueBook);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Issue_Book.class.getName()).log(Level.SEVERE, null, ex);
        }
        return issblist;
    }

    private boolean updateBookStatus(String isbn, int memberId, String newStatus,
            String note, Date returnDate, boolean updateQuantity) {
        try {
            // Định dạng ngày
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String returnDateStr = dateFormat.format(returnDate);

            // Cập nhật trạng thái mượn sách
            String updateQuery = "UPDATE `borrow` SET `Status` = ?, `note` = ?, `return_date` = ? "
                    + "WHERE `book_isbn` = ? AND `member_id` = ? AND "
                    + "(`Status` = 'Cho mượn' OR `Status` = 'Mượn sách')";

            // Cập nhật số lượng sách
            String updateBookQuery;
            if (updateQuantity) {
                // Trường hợp mất sách: giảm cả số lượng tổng và số lượng đã mượn
                updateBookQuery = "UPDATE `books` SET `quantity` = `quantity` - 1, `issued` = `issued` - 1 "
                        + "WHERE `isbn` = ?";
            } else {
                // Trường hợp trả sách: chỉ giảm số lượng đã mượn
                updateBookQuery = "UPDATE `books` SET `issued` = `issued` - 1 WHERE `isbn` = ?";
            }

            try (java.sql.Connection conn = DB.getConnection(); PreparedStatement ps = conn.prepareStatement(updateQuery); PreparedStatement psBook = conn.prepareStatement(updateBookQuery)) {

                // Thiết lập các tham số cho truy vấn cập nhật trạng thái mượn sách
                ps.setString(1, newStatus);
                ps.setString(2, note);
                ps.setString(3, returnDateStr);
                ps.setString(4, isbn);
                ps.setInt(5, memberId);

                // Thực hiện cập nhật
                int result = ps.executeUpdate();

                if (result > 0) {
                    // Cập nhật số lượng sách
                    psBook.setString(1, isbn);
                    psBook.executeUpdate();

                    return true;
                } else {
                    return false;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(ReturnBook.class.getName()).log(Level.SEVERE,
                    "Lỗi khi cập nhật trạng thái sách: " + ex.getMessage(), ex);
            return false;
        }
    }
}
